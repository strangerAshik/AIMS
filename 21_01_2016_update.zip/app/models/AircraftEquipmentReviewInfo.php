<?php

class AircraftEquipmentReviewInfo extends \Eloquent {
	protected $fillable = [];
	protected $table = 'aircraft_equipment_review_info';
}