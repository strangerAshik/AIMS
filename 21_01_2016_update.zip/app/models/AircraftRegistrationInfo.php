<?php

class AircraftRegistrationInfo extends \Eloquent {
	protected $fillable = [];
	protected $table = 'aircraft_registration_info';
}