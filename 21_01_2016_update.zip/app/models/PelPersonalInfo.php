<?php

class PelPersonalInfo extends \Eloquent {
	protected $fillable = [];
	protected $table ='pel_personal_info';

	
	
}
