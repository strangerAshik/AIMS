<?php

class level extends \Eloquent {
	protected $fillable = [];
	protected $table = 'levels';
}