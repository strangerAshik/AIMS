<?php

class OrgAirportAuth extends \Eloquent {
	protected $fillable = [];
	protected $table ='org_airport_auth';
}