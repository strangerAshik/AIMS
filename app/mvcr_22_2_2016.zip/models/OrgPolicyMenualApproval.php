<?php

class OrgPolicyMenualApproval extends \Eloquent {
	protected $fillable = [];
	protected $table ="org_policy_menual_approvals";
}