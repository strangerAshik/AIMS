<?php

class SCSafetyConcern extends \Eloquent {
	protected $fillable = [];
	protected $table ='sc_safety_concern';
}