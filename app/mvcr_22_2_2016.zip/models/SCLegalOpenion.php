<?php

class SCLegalOpenion extends \Eloquent {
	protected $fillable = [];
	protected $table ='sc_legal_openion';
}