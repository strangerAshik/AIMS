<?php

class OrgLeasingArrangment extends \Eloquent {
	protected $fillable = [];
	protected $table ='org_leasing_arrangment';
}