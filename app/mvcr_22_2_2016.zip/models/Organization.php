<?php

class Organization extends \Eloquent {
	protected $fillable = [];
	//
	//protected $table = 'organizations';
}