<?php

class OrgNonCertificatedOperation extends \Eloquent {
	protected $fillable = [];
	protected $table ='org_non_certificated_operations';
}