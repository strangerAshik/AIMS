<?php

class OrgExemptionsDivination extends \Eloquent {
	protected $fillable = [];
	protected $table ='org_exemptions_divinations';
}