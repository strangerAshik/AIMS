<?php

class SCCorrectiveAction extends \Eloquent {
	protected $fillable = [];
	protected $table ='sc_corrective_action';
}