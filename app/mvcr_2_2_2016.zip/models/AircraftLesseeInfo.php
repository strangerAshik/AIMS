<?php

class AircraftLesseeInfo extends \Eloquent {
	protected $fillable = [];
	protected $table = 'aircraft_lessee_info';
}