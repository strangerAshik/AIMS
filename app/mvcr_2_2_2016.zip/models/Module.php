<?php

class Module extends \Eloquent {
	protected $fillable = [];
	protected $table ='module_names';
}