<?php

class OrgAocMaintenanceArrangement extends \Eloquent {
	protected $fillable = [];
	protected $table ='org_aoc_maintenance_arrangement';
}