@if($PageName=='Designee Records')
@section('designeeRecordUpdate')
@foreach($designeeRecords as $info)
 <div class="modal fade" id="updateDesigneeRecords{{$info->id}}" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Update Designee Record </h4>
                </div>
				 <div class="modal-body">
                    <!-- The form is placed inside the body of modal -->
                   
					
					{{Form::open(array('url' => 'pel/updateDesigneeRecord', 'method' => 'post', 'files'=>true, 'class'=>'form-horizontal','data-toggle'=>'validator', 'role'=>'form'))}}

					 <div class="box-body">

						{{Form::hidden('id',$info->id)}}			  	
						{{Form::hidden('old_file',$info->file)}}			  	
				  		
						<div class="form-group required">
	                                           
												{{Form::label('active', 'Active', array('class' => 'col-xs-4 control-label'))}}
												
	                                <div class="col-xs-6">
												<div class="radio">									 
												 <label> {{ Form::radio('active', 'Yes',Input::old('active', $info->active == 'Yes'),array()) }} &nbsp  Yes</label>
												 <label> {{ Form::radio('active', 'No',Input::old('active', $info->active == 'No'),array()) }} &nbsp  No</label>
												</div>
										
									</div>
	                    </div>

	                     <div class="form-group required">
	                       
							{{Form::label('designation_type', 'Designation Type', array('class' => 'control-label col-xs-4 '))}}
							<div class="col-xs-6">
							{{Form::select('designation_type', array(
									'' => '--Select--',
									'Line Check Airman' => 'Line Check Airman',
									'Proficiency Check Airman'=>'Proficiency Check Airman',
									'Designated Airworthiness Representative'=>'Designated Airworthiness Representative',
									'Examiner'=>'Examiner',
									'Competency Check Evaluator'=>'Competency Check Evaluator',
									'Training Center Evaluator'=>'Training Center Evaluator',
									'Knowledge & Skill Evaluator'=>'Knowledge & Skill Evaluator',
									'Air Traffic Controller'=>'Air Traffic Controller'

									), $info->designation_type ,array('class'=>'form-control','required'=>''))}}
							</div>
							
	                    </div>
	                     <div class="form-group required">
	                       
							{{Form::label('designation_category', 'Designation Category', array('class' => 'control-label col-xs-4 '))}}
							<div class="col-xs-6">
							{{Form::select('designation_category', array(
									'' => '--Select--',
									'Training Device Only' => 'Training Device Only',
									'Simulator Only'=>'Simulator Only',
									'Aircraft Only'=>'Aircraft Only',
									'Simulator & Aircraft'=>'Simulator & Aircraft',
									'Line Check Only'=>'Line Check Only',
									'All Checks'=>'All Checks',
									'Oral Only'=>'Oral Only',
									'ATC Only'=>'ATC Only',
									'Not Applicable'=>'Not Applicable'

									), $info->designation_category,array('class'=>'form-control','required'=>''))}}
							</div>
							
	                    </div>		

						<div class="form-group  ">
							{{Form::label('business_address', 'Business Address', array('class' => 'control-label col-xs-4 '))}}
							<div class="col-xs-6">
							{{Form::textarea('business_address',$info->business_address, array('class' => 'form-control','placeholder'=>'','size'=>'4x1'))}}
							</div>
						</div>
						<div class="form-group required">
	                       
							{{Form::label('organization', 'Organization', array('class' => 'control-label col-xs-4 '))}}
							<div class="col-xs-6">
							{{Form::select('organization',$organizations,$info->organization,array('class'=>'form-control','required'=>''))}}
							</div>
							
	                    </div>
						<div class="form-group">
							{{Form::label('aircraft', 'Aircraft', array('class' => 'control-label col-xs-4'))}}
							<div class="col-xs-6">
							{{Form::text('aircraft',$info->aircraft, array('class' => 'form-control','placeholder'=>''))}}
							 </div>
						</div>

						<div class="form-group required">
	                                           
												{{Form::label('effective_date', 'Effective date', array('class' => 'col-xs-4 control-label'))}}
												
														<div class="row">
															<div class="col-xs-2">
															{{Form::select('effective_date', $dates,$info->effective_date,array('class'=>'form-control','required'=>''))}}
															</div>
															<div class="col-xs-3">
															{{Form::select('effective_month',$months,$info->effective_month,array('class'=>'form-control','required'=>''))}}
												
																
															</div>
															<div class="col-xs-2">
																{{Form::select('effective_year',$years,$info->effective_year,array('class'=>'form-control','required'=>''))}}
															</div>
														</div>
												
	                    </div>

						<div class="form-group ">
	                                           
												{{Form::label('expiration_date', 'Expiration date', array('class' => 'col-xs-4 control-label'))}}
												
														<div class="row">
															<div class="col-xs-2">
															{{Form::select('expiration_date', $dates,$info->expiration_date,array('class'=>'form-control'))}}
															</div>
															<div class="col-xs-3">
															{{Form::select('expiration_month',$months,$info->expiration_month,array('class'=>'form-control'))}}												
																
															</div>
															<div class="col-xs-2">
																{{Form::select('expiration_year',$years,$info->expiration_year,array('class'=>'form-control'))}}
															</div>
														</div>
												
	                    </div>	

						<div class="form-group  ">
							{{Form::label('function', 'Functions', array('class' => 'control-label col-xs-4 '))}}
							<div class="col-xs-6">
							{{Form::textarea('function',$info->function, array('class' => 'form-control','placeholder'=>'','size'=>'4x1'))}}
							</div>
						</div>
						<div class="form-group">
							{{Form::label('limitation', 'Limitation', array('class' => 'control-label col-xs-4 '))}}
							<div class="col-xs-6">
							{{Form::textarea('limitation',$info->limitation, array('class' => 'form-control','placeholder'=>'','size'=>'4x1'))}}
							</div>
						</div>
									
                        <div class="form-group ">
                        	{{ Form::label('file', 'Update File: ',array('class'=>'control-label col-xs-4')) }}
							 <div class="col-xs-6">
							@if($info->file!='Null'){{HTML::link('files/pelDesigneeRecord/'.$info->file,'Document',array('target'=>'_blank'))}}
							@else
								{{HTML::link('#','No Document Provided')}}
							@endif
							 </div>
							<div class="col-xs-6">
							  {{ Form::file('file') }}
							</div>
                        </div>
                                      
                                    </div><!-- /.box-body -->

                                   
									<div class="form-group">
                           
										<button type="submit" class="btn btn-lg btn-block btn-primary">Save</button>
                           
									</div>
	
									
					{{Form::close()}}
				</div>
			</div>
		</div>
	</div>
@endforeach

@stop
@endif


@if($PageName=='Medical Certification')
@section('updateMedicalCertification')
@foreach($medicalCertifications as $info)
 <div class="modal fade" id="updateMedicalCertifications{{$info->id}}" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Update Medical Certification</h4>
                </div>
				 <div class="modal-body">
                    <!-- The form is placed inside the body of modal -->
                   
					
					{{Form::open(array('url' => 'pel/updateMedicalCertification', 'method' => 'post', 'files'=>true, 'class'=>'form-horizontal','data-toggle'=>'validator', 'role'=>'form'))}}

					 <div class="box-body">
						{{Form::hidden('id',$info->id)}}			  	
						{{Form::hidden('old_file',$info->file)}}
						<div class="form-group required">
	                                           
												{{Form::label('active', 'Active', array('class' => 'col-xs-4 control-label'))}}
												
	                                <div class="col-xs-6">
											<div class="radio">										 
										 <label> {{ Form::radio('active', 'Yes',Input::old('active', $info->active == 'Yes'),array()) }} &nbsp  Yes</label>
												 <label> {{ Form::radio('active', 'No',Input::old('active', $info->active == 'No'),array()) }} &nbsp  No</label>
										</div>
										
									</div>
	                    </div>

	                     <div class="form-group required">
	                       
							{{Form::label('certificate_class', 'Certificate Class', array('class' => 'control-label col-xs-4 '))}}
							<div class="col-xs-6">
							{{Form::select('certificate_class', array(
									'' => '--Select--',
									'Class 1' => 'Class 1',
									'Class 2' => 'Class 2',
									'Class 3' => 'Class 3',
									'Not Issued' => 'Not Issued',
									'Suspended' => 'Suspended'
									), $info->certificate_class,array('class'=>'form-control','required'=>''))}}
							</div>
							
	                    </div>
	                     <div class="form-group required">
	                       
							{{Form::label('basis_for_issuance', 'Basis for Issuance', array('class' => 'control-label col-xs-4 '))}}
							<div class="col-xs-6">
							{{Form::select('basis_for_issuance', array(
									'' => '--Select--',
									'Flight Test' => 'Flight Test',
									'Medical Examination'=>'Medical Examination',
									'Oral Test'=>'Oral Test',
									'Personal Knowledge'=>'Personal Knowledge',
									'Validation'=>'Validation',
									'Written Test'=>'Written Test'
									), $info->basis_for_issuance,array('class'=>'form-control','required'=>''))}}
							</div>
							
	                    </div>	

						<div class="form-group required">
	                                           
												{{Form::label('effective_date', 'Effective date', array('class' => 'col-xs-4 control-label'))}}
												
														<div class="row">
															<div class="col-xs-2">
															{{Form::select('effective_date', $dates,$info->effective_date,array('class'=>'form-control','required'=>''))}}
															</div>
															<div class="col-xs-3">
															{{Form::select('effective_month',$months,$info->effective_month,array('class'=>'form-control','required'=>''))}}
												
																
															</div>
															<div class="col-xs-2">
																{{Form::select('effective_year',$years,$info->effective_year,array('class'=>'form-control','required'=>''))}}
															</div>
														</div>
												
	                    </div>

						<div class="form-group ">
	                                           
												{{Form::label('expiration_date', 'Expiration date', array('class' => 'col-xs-4 control-label'))}}
												
														<div class="row">
															<div class="col-xs-2">
															{{Form::select('expiration_date', $dates,$info->expiration_date,array('class'=>'form-control'))}}
															</div>
															<div class="col-xs-3">
															{{Form::select('expiration_month',$months,$info->expiration_month,array('class'=>'form-control'))}}												
																
															</div>
															<div class="col-xs-2">
																{{Form::select('expiration_year',$years,$info->expiration_year,array('class'=>'form-control'))}}
															</div>
														</div>
												
	                    </div>	
						<div class="form-group ">
	                                           
												{{Form::label('examination_date', 'Date of Examination', array('class' => 'col-xs-4 control-label'))}}
												
														<div class="row">
															<div class="col-xs-2">
															{{Form::select('examination_date', $dates,$info->examination_date,array('class'=>'form-control'))}}
															</div>
															<div class="col-xs-3">
															{{Form::select('examination_month',$months,$info->examination_month,array('class'=>'form-control'))}}												
																
															</div>
															<div class="col-xs-2">
																{{Form::select('examination_year',$years,$info->examination_year,array('class'=>'form-control'))}}
															</div>
														</div>
												
	                    </div>	

	


						<div class="form-group">
							{{Form::label('medical_examiner', 'Medical Examiner', array('class' => 'control-label col-xs-4'))}}
							<div class="col-xs-6">
							{{Form::text('medical_examiner',$info->medical_examiner, array('class' => 'form-control','placeholder'=>''))}}
							 </div>
						</div>

						<div class="form-group  ">
							{{Form::label('medical_limitation', 'Medical Limitation', array('class' => 'control-label col-xs-4 '))}}
							<div class="col-xs-6">
							{{Form::textarea('medical_limitation',$info->medical_limitation, array('class' => 'form-control','placeholder'=>'','size'=>'4x1'))}}
							</div>
						</div>
 						<div class="form-group ">
                        	{{ Form::label('file', 'Update File: ',array('class'=>'control-label col-xs-4')) }}
							 <div class="col-xs-6">
							@if($info->file!='Null'){{HTML::link('files/pelMedicalCertification/'.$info->file,'Document',array('target'=>'_blank'))}}
							@else
								{{HTML::link('#','No Document Provided')}}
							@endif
							 </div>
							<div class="col-xs-6">
							  {{ Form::file('file') }}
							</div>
                        </div>
                                      
                                    </div><!-- /.box-body -->

                                   
									<div class="form-group">
                           
										<button type="submit" class="btn btn-lg btn-block btn-primary">Save</button>
                           
									</div>
	
									
					{{Form::close()}}
				</div>
			</div>
		</div>
	</div>

@endforeach
@stop
@endif


@if($PageName=='License History')
@section('updateLicenseHistory')
@foreach($licenseHistorys as $info)
 <div class="modal fade" id="updateLicenseHistory{{$info->id}}" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Update License History</h4>
                </div>
				 <div class="modal-body">
                    <!-- The form is placed inside the body of modal -->
                   
					
					{{Form::open(array('url' => 'pel/updateLicenseHistory', 'method' => 'post', 'files'=>true, 'class'=>'form-horizontal','data-toggle'=>'validator', 'role'=>'form'))}}

					 <div class="box-body">
							{{Form::hidden('id',$info->id)}}			  	
						{{Form::hidden('old_file',$info->file)}}
						<div class="form-group required">
	                                           
												{{Form::label('active', 'Active', array('class' => 'col-xs-4 control-label'))}}
												
	                                <div class="col-xs-6">
										<div class="radio">
											<label> {{ Form::radio('active', 'Yes',Input::old('active', $info->active == 'Yes'),array()) }} &nbsp  Yes</label>
											<label> {{ Form::radio('active', 'No',Input::old('active', $info->active == 'No'),array()) }} &nbsp  No</label>
										</div>
										
									</div>
	                    </div>


						<div class="form-group required">
	                                           
												{{Form::label('effective_date', 'Effective date', array('class' => 'col-xs-4 control-label'))}}
												
														<div class="row">
															<div class="col-xs-2">
															{{Form::select('effective_date', $dates,$info->effective_date,array('class'=>'form-control','required'=>''))}}
															</div>
															<div class="col-xs-3">
															{{Form::select('effective_month',$months,$info->effective_month,array('class'=>'form-control','required'=>''))}}
												
																
															</div>
															<div class="col-xs-2">
																{{Form::select('effective_year',$years,$info->effective_year,array('class'=>'form-control','required'=>''))}}
															</div>
														</div>
												
	                    </div>

	                     <div class="form-group required">
	                       
							{{Form::label('certificate_type', 'Certificate Type', array('class' => 'control-label col-xs-4 '))}}
							<div class="col-xs-6">
							{{Form::select('certificate_type', array(
									'' => '--Select--',
									'Approved/Acceptable' => 'Approved/Acceptable',
									'Needs Further Training' => 'Needs Further Training',
									'Suspension' => 'Suspension',
									'Revocation' => 'Revocation',
									'Rating Rescinded' => 'Rating Rescinded',
									'No Action' => 'No Action',
									), $info->certificate_type,array('class'=>'form-control','required'=>''))}}
							</div>
							
	                    </div>
	                     <div class="form-group required">
	                       
							{{Form::label('historical_event', 'Historical Event', array('class' => 'control-label col-xs-4 '))}}
							<div class="col-xs-6">
							{{Form::select('historical_event', array(
									'' => '--Select--',
									'Written Exam' =>'Written Exam',
									'Oral Exam'=>'Oral Exam',
									'Practical Exam'=>'Practical Exam',
									'PIC Proficiency Check'=>'PIC Proficiency Check',
									'SIC Proficiency Check'=>'SIC Proficiency Check',
									'FA Competency Check'=>'FA Competency Check',
									'FO Competency Check'=>'FO Competency Check',
									'Other Proficiency/Competency Chek'=>'Other Proficiency/Competency Check',
									'PIC Line Check'=>'PIC Line Check',
									'Re-Examination'=>'Re-Examination',
									'Accident'=>'Accident',
									'Incident'=>'Incident',
									'Enforcement'=>'Enforcement',
									'Other Action'=>'Other Action',
									),  $info->historical_event,array('class'=>'form-control','required'=>''))}}
							</div>
							
	                    </div>	

	                     <div class="form-group required">
	                       
							{{Form::label('results', 'Results', array('class' => 'control-label col-xs-4 '))}}
							<div class="col-xs-6">
							{{Form::select('results', array(
									'' => '--Select--',
									'Approved/Acceptable' => 'Approved/Acceptable',
									'Needs Further Training' => 'Needs Further Training',
									'Suspension' => 'Suspension',
									'Revocation' => 'Revocation',
									'Rating Rescinded' => 'Rating Rescinded',
									'No Action' => 'No Action',
									),$info->results,array('class'=>'form-control','required'=>''))}}
							</div>
							
	                    </div>
						
						<div class="form-group required">
	                       
							{{Form::label('organization', 'Organization', array('class' => 'control-label col-xs-4 '))}}
							<div class="col-xs-6">
							{{Form::select('organization',$organizations,$info->organization,array('class'=>'form-control','required'=>''))}}
							</div>
							
	                    </div>
						<div class="form-group">
							{{Form::label('designation_number', 'Designation Number', array('class' => 'control-label col-xs-4'))}}
							<div class="col-xs-6">
							{{Form::text('designation_number',$info->designation_number, array('class' => 'form-control','placeholder'=>''))}}
							 </div>
						</div>
						<div class="form-group">
							{{Form::label('investigation_number', 'Investigation Number', array('class' => 'control-label col-xs-4'))}}
							<div class="col-xs-6">
							{{Form::text('investigation_number',$info->investigation_number, array('class' => 'form-control','placeholder'=>''))}}
							 </div>
						</div>

						<div class="form-group  ">
							{{Form::label('accident_number', 'Accident Number', array('class' => 'control-label col-xs-4 '))}}
							<div class="col-xs-6">
							{{Form::text('accident_number',$info->accident_number, array('class' => 'form-control','placeholder'=>''))}}
							</div>
						</div>

						<div class="form-group  ">
							{{Form::label('memo_notes', 'Memo/Notes', array('class' => 'control-label col-xs-4 '))}}
							<div class="col-xs-6">
							{{Form::textarea('memo_notes',$info->memo_notes, array('class' => 'form-control','placeholder'=>'','size'=>'4x1'))}}
							</div>
						</div>

                       
 						<div class="form-group ">
                        	{{ Form::label('file', 'Update File: ',array('class'=>'control-label col-xs-4')) }}
							 <div class="col-xs-6">
							@if($info->file!='Null'){{HTML::link('files/pelLicenseHistory/'.$info->file,'Document',array('target'=>'_blank'))}}
							@else
								{{HTML::link('#','No Document Provided')}}
							@endif
							 </div>
							<div class="col-xs-6">
							  {{ Form::file('file') }}
							</div>
                        </div>
                                      
                                    </div><!-- /.box-body -->

                                   
									<div class="form-group">
                           
										<button type="submit" class="btn btn-lg btn-block btn-primary">Save</button>
                           
									</div>
	
									
					{{Form::close()}}
				</div>
			</div>
		</div>
	</div>
@endforeach
@stop
@endif


@if($PageName=='Logbook Review')
@section('updateLogbookReview')
@foreach($logbookRecords as $info)
<div class="modal fade" id="updateLogbookReview{{$info->id}}" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Update Logbook Review</h4>
                </div>
				 <div class="modal-body">
                    <!-- The form is placed inside the body of modal -->
                   
					
					{{Form::open(array('url' => 'pel/updateLogbookReview', 'method' => 'post', 'files'=>true, 'class'=>'form-horizontal','data-toggle'=>'validator', 'role'=>'form'))}}

					 <div class="box-body">
						{{Form::hidden('id',$info->id)}}	
						<div class="form-group required">
	                                           
												{{Form::label('active', 'Active', array('class' => 'col-xs-4 control-label'))}}
												
	                                <div class="col-xs-6">
										<div class="radio">
											<label> {{ Form::radio('active', 'Yes',Input::old('active', $info->active == 'Yes'),array()) }} &nbsp  Yes</label>
											<label> {{ Form::radio('active', 'No',Input::old('active', $info->active == 'No'),array()) }} &nbsp  No</label>
										</div>
										
									</div>
	                    </div>


						<div class="form-group required">
	                                           
												{{Form::label('review_date', 'Date of Review', array('class' => 'col-xs-4 control-label'))}}
												
														<div class="row">
															<div class="col-xs-2">
															{{Form::select('review_date', $dates,$info->review_date,array('class'=>'form-control','required'=>''))}}
															</div>
															<div class="col-xs-3">
															{{Form::select('review_month',$months,$info->review_month,array('class'=>'form-control','required'=>''))}}
												
																
															</div>
															<div class="col-xs-2">
																{{Form::select('review_year',$years,$info->review_year,array('class'=>'form-control','required'=>''))}}
															</div>
														</div>
												
	                    </div>

	                     <div class="form-group required">
	                       
							{{Form::label('purpose_of_review', 'Purpose of Review', array('class' => 'control-label col-xs-4 '))}}
							<div class="col-xs-6">
							{{Form::select('purpose_of_review', array(
									'' => '--Select--',
									'After Accident' => 'After Accident',
									'After Incident' => 'After Incident',
									'Annual Review' => 'Annual Review',
									'Flight Test' => 'Flight Test',
									'Inspection' => 'Inspection'
									), $info->purpose_of_review ,array('class'=>'form-control','required'=>''))}}
							</div>
							
	                    </div>
	                     
						
						<div class="form-group">
							{{Form::label('flight_time', 'Flight Time', array('class' => 'control-label col-xs-4'))}}
							<div class="col-xs-6">
							{{Form::text('flight_time',$info->flight_time, array('class' => 'form-control','placeholder'=>''))}}
							 </div>
						</div>
						

						<div class="form-group  ">
							{{Form::label('memo_notes', 'Memo/Notes', array('class' => 'control-label col-xs-4 '))}}
							<div class="col-xs-6">
							{{Form::textarea('memo_notes',$info->memo_notes, array('class' => 'form-control','placeholder'=>'','size'=>'4x1'))}}
							</div>
						</div>

                                      
                                    </div><!-- /.box-body -->

                                   
									<div class="form-group">
                           
										<button type="submit" class="btn btn-lg btn-block btn-primary">Save</button>
                           
									</div>
	
									
					{{Form::close()}}
				</div>
			</div>
		</div>
</div>
@endforeach
@stop
@endif


@if($PageName=='Simulator')
@section('updateSimulator')
@foreach($simulatorHistorys as $info)
 <div class="modal fade" id="updateSimulator{{$info->id}}" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Update Simulator History</h4>
                </div>
				 <div class="modal-body">
                    <!-- The form is placed inside the body of modal -->
                   
					
					{{Form::open(array('url' => 'pel/updateSimulator', 'method' => 'post', 'files'=>true, 'class'=>'form-horizontal','data-toggle'=>'validator', 'role'=>'form'))}}

					 <div class="box-body">

						{{Form::hidden('id',$info->id)}}	


						<div class="form-group required">
	                                           
												{{Form::label('date', 'Date', array('class' => 'col-xs-4 control-label'))}}
												
														<div class="row">
															<div class="col-xs-2">
															{{Form::select('date', $dates,$info->date,array('class'=>'form-control','required'=>''))}}
															</div>
															<div class="col-xs-3">
															{{Form::select('month',$months,$info->month,array('class'=>'form-control','required'=>''))}}
												
																
															</div>
															<div class="col-xs-2">
																{{Form::select('year',$years,$info->year,array('class'=>'form-control','required'=>''))}}
															</div>
														</div>
												
	                    </div>

	                     
						
						<div class="form-group required">
							{{Form::label('model', 'Model', array('class' => 'control-label col-xs-4'))}}
							<div class="col-xs-6">
							{{Form::text('model',$info->model, array('class' => 'form-control','placeholder'=>'','required'=>''))}}
							 </div>
						</div>
						<div class="form-group required">
							{{Form::label('registration', 'Registration', array('class' => 'control-label col-xs-4'))}}
							<div class="col-xs-6">
							{{Form::text('registration',$info->registration, array('class' => 'form-control','placeholder'=>'','required'=>''))}}
							 </div>
						</div>
						<div class="form-group required">
							{{Form::label('location', 'Location', array('class' => 'control-label col-xs-4'))}}
							<div class="col-xs-6">
							{{Form::text('location',$info->location, array('class' => 'form-control','placeholder'=>'','required'=>''))}}
							 </div>
						</div>
						<div class="form-group">
							{{Form::label('other_crew_instructor', 'Other Crew / Instructor', array('class' => 'control-label col-xs-4'))}}
							<div class="col-xs-6">
							{{Form::text('other_crew_instructor',$info->other_crew_instructor, array('class' => 'form-control','placeholder'=>''))}}
							 </div>
						</div>
						<div class="form-group">
							{{Form::label('type_of_instruction', 'Type of Instruction', array('class' => 'control-label col-xs-4'))}}
							<div class="col-xs-6">
							{{Form::select('type_of_instruction', array(
									'' => '--Select--',									
									), $info->type_of_instruction,array('class'=>'form-control'))}}
							 </div>
						</div>
						<div class="form-group">
							{{Form::label('FFS_HR', 'FFS (HR)', array('class' => 'control-label col-xs-4'))}}
							<div class="col-xs-6">
							{{Form::text('FFS_HR',$info->FFS_HR, array('class' => 'form-control','placeholder'=>''))}}
							 </div>
						</div>
						<div class="form-group">
							{{Form::label('FNPT_1_HR', 'FNPT-I(HR)', array('class' => 'control-label col-xs-4'))}}
							<div class="col-xs-6">
							{{Form::text('FNPT_1_HR',$info->FNPT_1_HR, array('class' => 'form-control','placeholder'=>''))}}
							 </div>
						</div>
						<div class="form-group">
							{{Form::label('FNPT_II_HR', 'FNPT-II(HR)', array('class' => 'control-label col-xs-4'))}}
							<div class="col-xs-6">
							{{Form::text('FNPT_II_HR',$info->FNPT_II_HR, array('class' => 'form-control','placeholder'=>''))}}
							 </div>
						</div>
						<div class="form-group">
							{{Form::label('CSS_HR', 'CSS(HR)', array('class' => 'control-label col-xs-4'))}}
							<div class="col-xs-6">
							{{Form::text('CSS_HR',$info->CSS_HR, array('class' => 'form-control','placeholder'=>''))}}
							 </div>
						</div>
						<div class="form-group">
							{{Form::label('instruction_HR', 'Instruction (HR)', array('class' => 'control-label col-xs-4'))}}
							<div class="col-xs-6">
							{{Form::text('instruction_HR',$info->instruction_HR, array('class' => 'form-control','placeholder'=>''))}}
							 </div>
						</div>
						<div class="form-group">
							{{Form::label('exam_HR', 'EXAM (HR)', array('class' => 'control-label col-xs-4'))}}
							<div class="col-xs-6">
							{{Form::text('exam_HR',$info->exam_HR, array('class' => 'form-control','placeholder'=>''))}}
							 </div>
						</div>
						
  
                                    </div><!-- /.box-body -->

                                   
									<div class="form-group">
                           
										<button type="submit" class="btn btn-lg btn-block btn-primary">Save</button>
                           
									</div>
	
									
					{{Form::close()}}
				</div>
			</div>
		</div>
	</div>
@endforeach
@stop
@endif


@if($PageName=='PEL General')
@section('updategeneralInfo')
@foreach($generalInfos as $info)
 <div class="modal fade" id="updateGeneralInfo{{$info->id}}" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Update General Info.</h4>
                </div>
				 <div class="modal-body">
                    <!-- The form is placed inside the body of modal -->
                   
					
					{{Form::open(array('url' => 'pel/updateGeneral', 'method' => 'post', 'files'=>true, 'class'=>'form-horizontal','data-toggle'=>'validator', 'role'=>'form'))}}

					 <div class="box-body">
					 {{Form::hidden('id',$info->id)}}
					 <div class="form-group required">
	                                           
							{{Form::label('active', 'Active', array('class' => 'col-xs-4 control-label'))}}
												
	                        <div class="col-xs-6">
									<div class="radio">
								 
								<label> {{ Form::radio('active', 'Yes',Input::old('active', $info->active == 'Yes'),array()) }} &nbsp  Yes</label>
								<label> {{ Form::radio('active', 'No',Input::old('active', $info->active == 'No'),array()) }} &nbsp  No</label>
								</div>
								
							</div>
	                 </div>

                     <div class="form-group required">
	                       
							{{Form::label('license_type', 'License Type', array('class' => 'control-label col-xs-4 '))}}
							<div class="col-xs-6">
							{{Form::select('license_type', array(
									'' => '--Select--',
									'Aircraft Dispatcher' => 'Aircraft Dispatcher',
									'Medical Certificate' => 'Medical Certificate',
									'Aircraft Medical Technician' => 'Aircraft Medical Technician',
									'Aviation Repair Specialist' => 'Aviation Repair Specialist',
									'Aeronautical Station Operator' => 'Aeronautical Station Operator',
									'Airline Transport Pilot' => 'Airline Transport Pilot',
									'Commercial Pilot' => 'Commercial Pilot',
									'Flight Attendent' => 'Flight Attendent',
									'Flight Engineer' => 'Flight Engineer',
									'Flight Instructor' => 'Flight Instructor',
									'Ground Instructor' => 'Ground Instructor',
									'Master Parachute Rigger' => 'Master Parachute Rigger',
									'Private Pilot' => 'Private Pilot',
									'Senior parachute Rigger' => 'Senior parachute Rigger',
									'Aircraft maintenance Engineer' => 'Aircraft maintenance Engineer',
									'Air traffic Controller' => 'Air traffic Controller',
									'Flight Operation Officer' => 'Flight Operation Officer',
									'CPL (H)' => 'CPL (H)',
									'PPL (A)' => 'PPL (A)',
									'PPL (H)' => 'PPL (H)',
									
									), $info->license_type,array('class'=>'form-control','required'=>''))}}
							</div>
						
                    </div> 
                     <div class="form-group required">
	                       
							{{Form::label('license_rating', 'License Rating', array('class' => 'control-label col-xs-4 '))}}
							<div class="col-xs-6">
							{{Form::select('license_rating', array(
									'' => '--Select--',
									'Aircraft Dispatcher' => 'Aircraft Dispatcher',
									'Medical Certificate' => 'Medical Certificate',
									'Aircraft Medical Technician' => 'Aircraft Medical Technician',
									'Aviation Repair Specialist' => 'Aviation Repair Specialist',
									'Aeronautical Station Operator' => 'Aeronautical Station Operator',
									'Airline Transport Pilot' => 'Airline Transport Pilot',
									'Commercial Pilot' => 'Commercial Pilot',
									'Flight Attendent' => 'Flight Attendent',
									'Flight Engineer' => 'Flight Engineer',
									'Flight Instructor' => 'Flight Instructor',
									'Ground Instructor' => 'Ground Instructor',
									'Master Parachute Rigger' => 'Master Parachute Rigger',
									'Private Pilot' => 'Private Pilot',
									'Senior parachute Rigger' => 'Senior parachute Rigger',
									'Aircraft maintenance Engineer' => 'Aircraft maintenance Engineer',
									'Air traffic Controller' => 'Air traffic Controller',
									'Flight Operation Officer' => 'Flight Operation Officer',
									'CPL (H)' => 'CPL (H)',
									'PPL (A)' => 'PPL (A)',
									'PPL (H)' => 'PPL (H)',
									
									), $info->license_rating,array('class'=>'form-control','required'=>''))}}
							</div>
						
                    </div>               
						
						<div class="form-group required">
	                                           
												{{Form::label('issued_date', 'Issued date', array('class' => 'col-xs-4 control-label'))}}
												
														<div class="row">
															<div class="col-xs-2">
															{{Form::select('issued_date', $dates,$info->issued_date,array('class'=>'form-control','required'=>''))}}
															</div>
															<div class="col-xs-3">
															{{Form::select('issued_month',$months,$info->issued_month,array('class'=>'form-control','required'=>''))}}
												
																
															</div>
															<div class="col-xs-2">
																{{Form::select('issued_year',$years,$info->issued_year,array('class'=>'form-control','required'=>''))}}
															</div>
														</div>
												
	                    </div>

						<div class="form-group ">
                               
								{{Form::label('expiration_date', 'Expiration date', array('class' => 'col-xs-4 control-label'))}}
								
										<div class="row">
											<div class="col-xs-2">
											{{Form::select('expiration_date', $dates,$info->expiration_date,array('class'=>'form-control'))}}
											</div>
											<div class="col-xs-3">
											{{Form::select('expiration_month',$months,$info->expiration_month,array('class'=>'form-control'))}}												
												
											</div>
											<div class="col-xs-2">
												{{Form::select('expiration_year',$years,$info->expiration_year,array('class'=>'form-control'))}}
											</div>
										</div>
												
	                    </div>	
						</div>
						<div class="form-group ">
							{{Form::label('old_certificate_number', 'Old Certificate Number', array('class' => 'control-label col-xs-4'))}}
							<div class="col-xs-6">
							{{Form::text('old_certificate_number',$info->old_certificate_number, array('class' => 'form-control','placeholder'=>''))}}
							 </div>
						</div>

	                    <div class="form-group ">
		                       
								{{Form::label('basis_for_issuance', 'Basis for Issuance', array('class' => 'control-label col-xs-4 '))}}
								<div class="col-xs-6">
								{{Form::select('basis_for_issuance', array(
										'' => '--Select--',
										'Flight Test' => 'Flight Test',
										'Medical Examination' => 'Medical Examination',
										'Oral Test' => 'Oral Test',
										'Personal Knowledge' => 'Personal Knowledge',
										'Validation' => 'Validation',
										'Written Test' => 'Written Test',
										
										),$info->basis_for_issuance,array('class'=>'form-control'))}}
								</div>
							
	                    </div> 
	                    <div class="form-group ">
		                       
								{{Form::label('category', 'Category', array('class' => 'control-label col-xs-4 '))}}
								<div class="col-xs-6">
								{{Form::select('category', array(
										'' => '--Select--',
										'Arpplane Single Engine Land' => 'Arpplane Single Engine Land',
										'Airplane Multi Engine Land' => 'Airplane Multi Engine Land'			
										),$info->category,array('class'=>'form-control'))}}
								</div>
							
	                    </div> 
						<div class="form-group ">
							{{Form::label('class', 'Class', array('class' => 'control-label col-xs-4'))}}
							<div class="col-xs-6">
							{{Form::text('class',$info->class, array('class' => 'form-control','placeholder'=>''))}}
							 </div>
						</div>
						<div class="form-group">
							{{Form::label('ratings', 'Ratings', array('class' => 'control-label col-xs-4'))}}
							<div class="col-xs-6">
							{{Form::textarea('ratings',$info->ratings, array('class' => 'form-control','placeholder'=>'','size'=>'4x1'))}}
							 </div>
						</div>
						<div class="form-group">
							{{Form::label('endorsement', 'Endorsement', array('class' => 'control-label col-xs-4'))}}
							<div class="col-xs-6">
							{{Form::textarea('endorsement',$info->endorsement, array('class' => 'form-control','placeholder'=>'','size'=>'4x1'))}}
							 </div>
						</div>
						<div class="form-group">
							{{Form::label('limitations', 'Limitations', array('class' => 'control-label col-xs-4'))}}
							<div class="col-xs-6">
							{{Form::text('limitations',$info->limitations, array('class' => 'form-control','placeholder'=>''))}}
							 </div>
						</div>
						
  
                                    </div><!-- /.box-body -->

                                   
									<div class="form-group">
                           
										<button type="submit" class="btn btn-lg btn-block btn-primary">Save</button>
                           
									</div>
	
									
					{{Form::close()}}
				</div>
			</div>
		</div>
	</div>
@endforeach
@stop
@endif


@if($PageName=='Trainging Details')
@section('updatetrainingDetails')
@foreach($trainingDetails as $info)
 <div class="modal fade" id="updateTrainingDetails{{$info->id}}" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Update Training Details</h4>
                </div>
				 <div class="modal-body">
                    <!-- The form is placed inside the body of modal -->
                   
					
					{{Form::open(array('url' => 'pel/updateTrainingDetails', 'method' => 'post', 'files'=>true, 'class'=>'form-horizontal','data-toggle'=>'validator', 'role'=>'form'))}}

					 <div class="box-body">
					
						{{Form::hidden('id',$info->id)}}			  	
						{{Form::hidden('old_file',$info->file)}}
						<div class="form-group required">
							{{Form::label('name_of_the_course', 'Name of The course', array('class' => 'control-label col-xs-4'))}}
							<div class="col-xs-6">
							{{Form::text('name_of_the_course',$info->name_of_the_course, array('class' => 'form-control','placeholder'=>'','required'=>''))}}
							 </div>
						</div>  
						<div class="form-group required">
							{{Form::label('name_of_the_institute', 'Name Of The Institute', array('class' => 'control-label col-xs-4'))}}
							<div class="col-xs-6">
							{{Form::text('name_of_the_institute',$info->name_of_the_institute, array('class' => 'form-control','placeholder'=>'','required'=>''))}}
							 </div>
						</div>     
						
						<div class="form-group required">
	                                           
												{{Form::label('start_date', 'Start Date', array('class' => 'col-xs-4 control-label'))}}
												
														<div class="row">
															<div class="col-xs-2">
															{{Form::select('start_date', $dates,$info->start_date,array('class'=>'form-control','required'=>''))}}
															</div>
															<div class="col-xs-3">
															{{Form::select('start_month',$months,$info->start_month,array('class'=>'form-control','required'=>''))}}
												
																
															</div>
															<div class="col-xs-2">
																{{Form::select('start_year',$years,$info->start_year,array('class'=>'form-control','required'=>''))}}
															</div>
														</div>
												
	                    </div>	
						<div class="form-group required">
	                                           
												{{Form::label('end_date', 'End Date', array('class' => 'col-xs-4 control-label'))}}
												
														<div class="row">
															<div class="col-xs-2">
															{{Form::select('end_date', $dates,$info->end_date,array('class'=>'form-control','required'=>''))}}
															</div>
															<div class="col-xs-3">
															{{Form::select('end_month',$months,$info->end_month,array('class'=>'form-control','required'=>''))}}
												
																
															</div>
															<div class="col-xs-2">
																{{Form::select('end_year',$years,$info->end_year,array('class'=>'form-control','required'=>''))}}
															</div>
														</div>
												
	                    </div>
	
						</div>
						<div class="form-group ">
							{{Form::label('duration', 'Duration', array('class' => 'control-label col-xs-4'))}}
							<div class="col-xs-6">
							{{Form::text('duration',$info->duration, array('class' => 'form-control','placeholder'=>''))}}
							 </div>
						</div>

						<div class="form-group required">
	                                           
												{{Form::label('date_of_certificate_issue', 'Date Of Certificate Issue', array('class' => 'col-xs-4 control-label'))}}
												
														<div class="row">
															<div class="col-xs-2">
															{{Form::select('certificate_issue_date', $dates,$info->certificate_issue_date,array('class'=>'form-control','required'=>''))}}
															</div>
															<div class="col-xs-3">
															{{Form::select('certificate_issue_month',$months,$info->certificate_issue_month,array('class'=>'form-control','required'=>''))}}
												
																
															</div>
															<div class="col-xs-2">
																{{Form::select('certificate_issue_year',$years,$info->certificate_issue_year,array('class'=>'form-control','required'=>''))}}
															</div>
														</div>
												
	                    </div>

	                    <div class="form-group ">
	                                           
												{{Form::label('expiration_date', 'Expiration date', array('class' => 'col-xs-4 control-label'))}}
												
														<div class="row">
															<div class="col-xs-2">
															{{Form::select('expiration_date', $dates,$info->expiration_date,array('class'=>'form-control'))}}
															</div>
															<div class="col-xs-3">
															{{Form::select('expiration_month',$months,$info->expiration_month,array('class'=>'form-control'))}}												
																
															</div>
															<div class="col-xs-2">
																{{Form::select('expiration_year',$years,$info->expiration_year,array('class'=>'form-control'))}}
															</div>
														</div>
												
	                    </div>	

 						<div class="form-group ">
                        	{{ Form::label('file', 'Update File: ',array('class'=>'control-label col-xs-4')) }}
							 <div class="col-xs-6">
							@if($info->file!='Null'){{HTML::link('files/pelTrainingDetails/'.$info->file,'Document',array('target'=>'_blank'))}}
							@else
								{{HTML::link('#','No Document Provided')}}
							@endif
							 </div>
							<div class="col-xs-6">
							  {{ Form::file('file') }}
							</div>
                        </div>
						<div class="form-group">
							{{Form::label('approved_by', 'Approved By', array('class' => 'control-label col-xs-4'))}}
							<div class="col-xs-6">
							{{Form::text('approved_by',$info->approved_by, array('class' => 'form-control','placeholder'=>''))}}
							 </div>
						</div>
						
  
                                    </div><!-- /.box-body -->

                                   
						<div class="form-group">
               
							<button type="submit" class="btn btn-lg btn-block btn-primary">Save</button>
               
						</div>
	
									
					{{Form::close()}}
				</div>
			</div>
		</div>
	</div>

@endforeach
@stop
@endif