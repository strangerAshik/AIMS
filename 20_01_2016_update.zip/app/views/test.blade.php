<!DOCTYPE html>
<html>
<head>
  <title>Ajax</title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script>

</head>
<body>
<div class="container">
  <a href="#" id='get'>Get</a>
  <a href="#" id='set'></a>
  <select id='sel'>
    <option selected="">1</option>
    <option>2</option>
    <option>3</option>
  </select>
</div>



</body>
</html>