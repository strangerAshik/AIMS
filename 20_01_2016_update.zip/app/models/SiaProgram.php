<?php

class SiaProgram extends \Eloquent {
	protected $fillable = [];
	protected $table ='sia_program';
}