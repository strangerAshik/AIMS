<?php

class SCApprovalInfo extends \Eloquent {
	protected $fillable = [];
	protected $table ='sc_approval_info';
}