<?php

class AircraftCAAApprovalInfo extends \Eloquent {
	protected $fillable = [];
	protected $table = 'aircraft_caa_approval_info';
}