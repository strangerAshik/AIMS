<?php

class SCForwarding extends \Eloquent {
	protected $fillable = [];
	protected $table ='sc_forwarding';
}