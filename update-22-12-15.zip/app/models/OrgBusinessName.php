<?php

class OrgBusinessName extends \Eloquent {
	protected $fillable = [];
	protected $table ='org_business_name';
}