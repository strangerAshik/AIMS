<?php

class AircraftSTCInfo extends \Eloquent {
	protected $fillable = [];
	protected $table = 'aircraft_stc_info';
}