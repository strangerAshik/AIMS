<?php

class OrgManagementContact extends \Eloquent {
	protected $fillable = [];
	protected $table ='org_management_contacts';
}