<?php

class PelAccademy extends \Eloquent {
	protected $fillable = [];
	protected $table ='pel_accademy';
}