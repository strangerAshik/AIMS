<?php

class OrgContractedService extends \Eloquent {
	protected $fillable = [];
	protected $table ='org_contracted_services';
}