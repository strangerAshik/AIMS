<?php

class PelAccaThesisProject extends \Eloquent {
	protected $fillable = [];
	protected $table ='pel_acca_thesis_project';
}