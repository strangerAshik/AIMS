=======================================================================================================================
Function Title: 
Update Tracking of a Module
Function:
protected  function updateTracking($tableName,$orgNum)
Description:
This function keep track all kind of changes in a module. 
This is made specially for Organization module
Location:
Controller->OrganizationController
Used at:
all edit and insert form's controller functions
=======================================================================================================================
Function Title:
Last Update Time and Updater pulling function 
Function: 
static function lastUpdateDate($orgNum)
static function lastUpdator($orgNum)
Description: Functions are pulling data direct at view from the update tracking table the last updator and the update thims
Location:Model->OrgCommonFunction
Used at:Org List view 
=======================================================================================================================

Function Title:
Function: 
Description: 
Location:
Used at:
=======================================================================================================================

Function Title:
Function: 
Description: 
Location:
Used at:
=======================================================================================================================

Function Title:
Function: 
Description: 
Location:''
Used at:
=======================================================================================================================

Function Title:
Function: 
Description: 
Location:
Used at:
=======================================================================================================================

Function Title:
Function: 
Description: 
Location:
Used at:

=======================================================================================================================

Function Title:
Function: 
Description: 
Location:
Used at:

=======================================================================================================================
