<?php

class Aircraft extends \Eloquent {
	protected $fillable = [];
	
	static function options($table,$id){
	return	"
			
			";
	
	}
}