<?php

class OrgPrimary extends \Eloquent {
	protected $fillable = [];
	protected $table ="org_primary";
}