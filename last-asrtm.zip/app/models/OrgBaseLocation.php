<?php

class OrgBaseLocation extends \Eloquent {
	protected $fillable = [];
	protected $table ='org_base_location';
}