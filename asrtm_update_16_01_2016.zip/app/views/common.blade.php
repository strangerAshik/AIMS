
@section('print')
<a class="btn btn-primary hidden-print"id='printOption' onclick=" myFunction();">Print/Save</a>
<script>
function myFunction() {
    window.print();
}

</script>
@stop