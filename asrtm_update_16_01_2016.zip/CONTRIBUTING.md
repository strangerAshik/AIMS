# Contribution Guidelines

Please submit all issues and pull requests to the [laravel/framework](http://github.com/laravel/framework) repository!
