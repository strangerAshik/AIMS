<?php

class AircraftInsurerInfo extends \Eloquent {
	protected $fillable = [];
	protected $table = 'aircraft_insurer_info';
}